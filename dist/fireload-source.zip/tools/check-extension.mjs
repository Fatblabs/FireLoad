import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { spawnSync } from "node:child_process";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const manifestPath = path.join(root, "manifest.json");
const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
const packageJson = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
if (packageJson.version !== manifest.version) throw new Error("Manifest and package versions must match.");

const required = new Set(["manifest.json"]);

function addFile(file) {
  if (file) required.add(file);
}

function addHtmlReferences(file) {
  const html = fs.readFileSync(path.join(root, file), "utf8");
  const baseDir = path.dirname(file);
  const referencePattern = /\b(?:href|src)=["']([^"']+)["']/g;
  for (const match of html.matchAll(referencePattern)) {
    const reference = match[1];
    if (/^(?:[a-z]+:|#|\/)/i.test(reference)) continue;
    required.add(path.normalize(path.join(baseDir, reference)));
  }
}

Object.values(manifest.icons || {}).forEach(addFile);
Object.values(manifest.action?.default_icon || {}).forEach(addFile);
addFile(manifest.action?.default_popup);
addFile(manifest.options_ui?.page);
addFile("onboarding/onboarding.html");
(manifest.background?.scripts || []).forEach(addFile);
(manifest.content_scripts || []).forEach((entry) => (entry.js || []).forEach(addFile));

for (const htmlFile of [manifest.action?.default_popup, manifest.options_ui?.page, "onboarding/onboarding.html"].filter(Boolean)) {
  addHtmlReferences(htmlFile);
}

for (const file of required) {
  const fullPath = path.join(root, file);
  if (!fs.existsSync(fullPath)) {
    throw new Error(`Missing manifest file: ${file}`);
  }
}

const scripts = [
  "src/shared.js",
  "src/background.js",
  "src/content.js",
  "popup/popup.js",
  "options/options.js"
];

for (const script of scripts) {
  const source = fs.readFileSync(path.join(root, script), "utf8");
  new vm.Script(source, { filename: script });
}

for (const file of fs.readdirSync(path.join(root, "tools"))) {
  if (!file.endsWith(".mjs") && !file.endsWith(".cjs")) continue;
  const result = spawnSync(process.execPath, ["--check", path.join(root, "tools", file)], { encoding: "utf8" });
  if (result.status !== 0) throw new Error(result.stderr || `Syntax error in tools/${file}`);
}

if (manifest.manifest_version !== 3) {
  throw new Error("FireLoad currently targets Firefox Manifest V3.");
}

if (manifest.browser_action) {
  throw new Error("Manifest V3 must use action, not browser_action.");
}

if (manifest.homepage_url?.includes("/local/")) {
  throw new Error("homepage_url must not use a local placeholder value.");
}

if (manifest.browser_specific_settings?.gecko?.id !== "fireload@local.dev") {
  throw new Error("Gecko id must match the existing AMO listing id: fireload@local.dev.");
}

const hostPermissions = manifest.host_permissions || [];
if (hostPermissions.includes("<all_urls>")) {
  throw new Error("Use explicit http/https host permissions instead of <all_urls>.");
}

for (const expectedPermission of ["http://*/*", "https://*/*"]) {
  if (!hostPermissions.includes(expectedPermission)) {
    throw new Error(`Missing host permission required for Firefox static content script injection: ${expectedPermission}`);
  }
}

const contentMatches = manifest.content_scripts?.flatMap((entry) => entry.matches || []) || [];
if (contentMatches.includes("<all_urls>")) {
  throw new Error("Content scripts should use explicit http/https matches instead of <all_urls>.");
}

for (const expectedMatch of ["http://*/*", "https://*/*"]) {
  if (!contentMatches.includes(expectedMatch)) {
    throw new Error(`Missing content script match: ${expectedMatch}`);
  }
}

const csp = manifest.content_security_policy?.extension_pages || "";
for (const directive of ["script-src 'self'", "object-src 'none'", "connect-src 'none'"]) {
  if (!csp.includes(directive)) {
    throw new Error(`Missing CSP directive: ${directive}`);
  }
}

for (const mode of ["efficiency", "balanced", "blazing"]) {
  if (!fs.readFileSync(path.join(root, "src/shared.js"), "utf8").includes(`${mode}:`)) {
    throw new Error(`Missing mode config: ${mode}`);
  }
}

console.log("Extension structure and JavaScript syntax look good.");
